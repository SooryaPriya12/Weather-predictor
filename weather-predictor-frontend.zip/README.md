See index.html — frontend-only weather predictor demo.

Model trained on synthetic data. Replace coefficients with ones trained on real data for production.